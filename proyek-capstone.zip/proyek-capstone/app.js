// ==============================================================
//  Agenda Pribadi: aplikasi web berlogin yang bisa dipasang di HP.
//  Data tersimpan di project Supabase milikmu sendiri. Kerjakan
//  fungsi bertanda "Minggu N" pada minggu itu.
// ==============================================================

// ---- Minggu 1 · Salin dari Supabase: Project Settings → API ----
const SUPABASE_URL = "https://lrksemkaebodhqmjtvxu.supabase.co";
const SUPABASE_KEY = "sb_publishable_L28bqxBhitgAeQm66-IRBQ_wx-NljUK"; // HANYA kunci publik (publishable/anon)

// Minggu 1 · Kenali jenis kunci API

function jenisKunci(kunci) {
    if (kunci.startsWith("sb_publishable_")) {
        return "publik";
    }
    if (kunci.startsWith("sb_secret_")) {
        return "rahasia";
    }
    if (kunci.startsWith("eyJ")) {
        try {
            const payload = JSON.parse(
                atob(kunci.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))
            );

            if (payload.role === "anon") {
                return "publik";
            }

            if (payload.role === "service_role") {
                return "rahasia";
            }
        } catch (error) {
            return "tidak dikenal";
        }
    }
    return "tidak dikenal";
}


// Minggu 2 · Susun alamat REST Supabase
function alamatREST(urlProyek, tabel, filter) {
  return urlProyek + "/rest/v1/" + tabel; // tambahkan ?select=* dan filter kolom=eq.nilai
}

// Minggu 3 · Pesan untuk kode status HTTP
function pesanStatus(kode) {
  return "Berhasil"; // bedakan 2xx, 400, 401, 403, 404, 409, 429, 5xx, dan 0
}

// Minggu 4 · Periksa manifest PWA
function periksaManifest(manifest) {
  return []; // kembalikan daftar isian manifest yang masih kurang
}

// Minggu 5 · Periksa isian daftar/masuk
function validasiAkun(email, sandi) {
  const galat = [];
  if (sandi.length < 6) galat.push("Kata sandi minimal 8 karakter");
  return galat; // periksa juga format email serta huruf dan angka pada sandi
}

// Minggu 6 · Amankan teks sebelum ditampilkan
function amankanTeks(teks) {
  return teks; // ubah & < > " ' menjadi entitas HTML
}

// Minggu 7 · Aturan akses baris (cerminan kebijakan RLS)
function bolehAkses(penggunaId, baris) {
  return true; // hanya pengguna yang masuk dan memiliki baris itu
}

// Minggu 8 · Strategi cache service worker
function strategiCache(url, asal) {
  return "cache-dulu"; // bedakan berkas aplikasi, data REST, dan login
}

// Minggu 9 · Antrean saat offline
class AntrianOffline {
  constructor() {
    this.isi = [];
  }

  tambah(aksi) {
    this.isi.push(aksi);
  }

  ambilBerikut() {
    return this.isi.pop(); // yang pertama masuk harus keluar lebih dulu; kosong → null
  }

  jumlah() {
    return this.isi.length;
  }
}

// Minggu 10 · Jeda sebelum mencoba ulang
function jedaCobaUlang(percobaan) {
  return 1000; // mulai 500 ms, berlipat dua, paling lama 8000 ms
}

// Minggu 11 · Sesi masih berlaku?
function sesiBerlaku(kedaluwarsa, sekarang) {
  return kedaluwarsa > sekarang; // beri jarak aman 60 detik; tanpa sesi → false
}

// Minggu 12 · Kelompokkan agenda
function kelompokkanAgenda(daftar, hariIni) {
  return { terlambat: [], hariIni: daftar, mendatang: [], selesai: [] }; // lengkapi semua kelompok
}

// Minggu 13 · Batasi percobaan masuk
function bolehKirim(riwayat, sekarang) {
  return true; // paling banyak 5 kali dalam 60 detik terakhir
}

// Minggu 14 · Periksa alamat terbit
function periksaTerbit(url) {
  return []; // HTTPS, bukan alamat lokal, dan folder diakhiri "/"
}

// Minggu 15 · Siap rilis?
function siapRilis(hasil) {
  return true; // siap hanya bila ada hasil uji dan semuanya lulus
}

// ---- Fungsi Supabase: dikerjakan bertahap sesuai materi ----
// Setiap fungsi mengembalikan hasil dari supabase-js: { data, error }.

function buatKlien() {
  return supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
}

// Minggu 2 · Ambil agenda milikmu, urut dari tenggat terdekat
async function muatAgenda(klien) {
  return { data: [], error: null };
}

// Minggu 3 · Simpan, tandai selesai, dan hapus agenda
async function simpanAgenda(klien, data) {
  return { data: null, error: { message: "simpanAgenda belum dibuat" } };
}

async function ubahSelesai(klien, id, selesai) {
  return { data: null, error: { message: "ubahSelesai belum dibuat" } };
}

async function hapusAgenda(klien, id) {
  return { data: null, error: { message: "hapusAgenda belum dibuat" } };
}

// Minggu 5 · Daftar, masuk, dan keluar
async function daftarAkun(klien, email, sandi) {
  return { data: null, error: { message: "daftarAkun belum dibuat" } };
}

async function masukAkun(klien, email, sandi) {
  return { data: null, error: { message: "masukAkun belum dibuat" } };
}

async function keluarAkun(klien) {
  return { error: null };
}
